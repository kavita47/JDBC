package com.cg.wallet.exception;

public class inputException extends RuntimeException{
	public inputException(String msg) {
		super(msg);
	}

}
