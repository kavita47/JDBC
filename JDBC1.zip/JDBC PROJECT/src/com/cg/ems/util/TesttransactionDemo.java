package com.cg.ems.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class TesttransactionDemo {
	public static void main(String args[])
	
	{   
		Connection con = null;
	
		try {
		 con = DBUTIL.getCon();
		String update1 ="Update emp19 set emp_name= 'vaishalis' where emp_id=133";	
		String update2 = "Update emp19 set emp_name= vaish where emp_id=116";			
		Statement st = con.createStatement();
		st.addBatch(update1);
		st.addBatch(update2);
		int arr[]=st.executeBatch();
		con.commit();
		System.out.println("update is success");
		
		
		
		}catch (SQLException | IOException e )
		{
			try {
				con.rollback();
			} catch(SQLException e1){
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

}
