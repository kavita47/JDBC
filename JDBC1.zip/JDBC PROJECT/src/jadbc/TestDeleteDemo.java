package jadbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.ems.util.DBUTIL;

public class TestDeleteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the emp id ");
		Scanner sc = new Scanner(System.in);
		
		int eid = sc.nextInt();
		
		try {
			Connection con = DBUTIL.getCon();
			String deleteQry = "DELETE FROM abc where emp_id =?";
					
			PreparedStatement pst = con.prepareStatement(deleteQry);
			pst.setInt(1, eid);
			int data =  pst.executeUpdate();
			System.out.println("data deleted "+data);
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		

	}

}
