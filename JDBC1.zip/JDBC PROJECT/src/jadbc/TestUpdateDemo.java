package jadbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.ems.util.DBUTIL;

public class TestUpdateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("enter empid ");
		Scanner sc = new Scanner(System.in);
		int eid =  sc.nextInt();
		
		System.out.println("enter empname ");
		Scanner sc1 = new Scanner(System.in);
		String ename =  sc1.nextLine();
		
		System.out.println("enter salary ");
		Scanner sc2 = new Scanner(System.in);
		float  esal =  sc2.nextFloat();
		
		try {
			Connection con = DBUTIL.getCon();
			String updateQry = "UPDATE abc SET emp_name=?,emp_sal=? where emp_id=? ";
			PreparedStatement pst = con.prepareStatement(updateQry);
			pst.setInt(1, eid);
			pst.setString(2, ename);
			pst.setFloat(3, esal);
			int data =  pst.executeUpdate();
			System.out.println("data updated");
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		

	}

}
