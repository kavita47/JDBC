package com.capgemini.ems.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity //annotation 
@Table(name="emp1")
public class Employee {
	
	@Id //mapp the emp_id with primary key in the table
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "emp_id",length =10)//this is for mapping
    private int empId;
	@Column(name = "emp_name",length=20)
	private String empName;
	@Column(name = "emp_sal",length=10)
	private float empSal;
	
	@Transient 
	// then jpa will not map this property 
	//because lot of conversition we have to do 
	//that is why we have avoid it
	
	private LocalDate empdoj;
	
	
	public int getEmpId() {
		return empId;
	}
	/**
	 * 
	 */
	public Employee() {
		super();
	}
	/**
	 * 
	 */
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empdoj=" + empdoj + "]";
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public LocalDate getEmpdoj() {
		return empdoj;
	}
	public void setEmpdoj(LocalDate empdoj) {
		this.empdoj = empdoj;
	}
	/**
	 * @param empId
	 * @param empName
	 * @param empSal
	 * @param empdoj
	 */
	public Employee(int empId, String empName, float empSal, LocalDate empdoj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empdoj = empdoj;
	}

}
