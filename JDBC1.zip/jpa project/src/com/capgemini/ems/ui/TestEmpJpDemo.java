package com.capgemini.ems.ui;

import java.util.ArrayList;

import com.capgemini.ems.bean.Employee;
import com.capgemini.ems.service.EmployeeService;
import com.capgemini.ems.service.EmployeeServiceImp;

public class TestEmpJpDemo {

	public static void main(String[] args) {
	  
		
		EmployeeService empSer = new  EmployeeServiceImp();// This is our empSer object
	   
		// this code is for inserting the record in the database 
		Employee e1 = new Employee();
		e1.setEmpName("aaa");
		e1.setEmpSal(80000.0F);
		Employee ee1=empSer.addEmp(e1);
		System.out.println(ee1 +"\n "+"and are inserted in the table ");
		
		//this code is for fetching all the data from the database
		Employee ee = empSer.getEmpbyEid(555);
		System.out.println(ee);
		System.out.println("-----------fetch all record ");
		ArrayList<Employee> eList = empSer.fetchAllEmp() ;
		for(Employee tempE:eList)
		
			
		//this is for deleting the record from the database 
	    System.out.println(tempE.getEmpId()+"\t"+tempE.getEmpName()+"\t"+tempE.getEmpSal());
		Employee deletedEmp = empSer.deleteEmp(555);
		System.out.println(deletedEmp +"deleted");
		
		
		// this code is for updating the data in the data base 
		System.out.println("--------update----");
		Employee updatedE= empSer.updateEmp(1120, "kavita", 90000);
		System.out.println("updated data for"+updatedE.getEmpId());
		
		
	}

}
