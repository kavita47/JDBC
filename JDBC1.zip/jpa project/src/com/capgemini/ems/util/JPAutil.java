package com.capgemini.ems.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAutil {
	private static EntityManagerFactory emf = null;//THIS FOR CONNECTION 
	private static EntityManager em = null; // THIS IS FOR MANAGING CONNECTION 
	
	
	public static EntityManager getEntityManager()
	{
		emf=Persistence.
				createEntityManagerFactory("ORACLE-JPA-PU");
		em = emf.createEntityManager();
		return em;
		
	}

}
