package com.capgemini.ems.doa;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.capgemini.ems.bean.Employee;
import com.capgemini.ems.util.JPAutil;

public class EmployeeDaoImp implements EmployeeDao{
	EntityManager em = null;
	EntityTransaction entitytran = null;
	

	public EmployeeDaoImp() {
		em = JPAutil.getEntityManager();
		entitytran = em.getTransaction();
	}

	@Override //they are called function 
	public Employee addEmp(Employee emp) {
		entitytran.begin();
		em.persist(emp);
		entitytran.commit();
		return emp;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		
		String selAllQry="SELECT emps FROM Employee emps";
		TypedQuery<Employee> tq = em.createQuery(selAllQry,Employee.class);
		ArrayList<Employee> empList = (ArrayList) tq.getResultList();
		
		
		return empList;
	}

	@Override
	public Employee deleteEmp(int empId) {
		Employee e1 = em.find(Employee.class,empId) ;
		entitytran.begin();
		em.remove(e1);
		entitytran.commit();
		return e1;
	}

	@Override
	public Employee getEmpbyEid(int empId) {
		Employee ee = em.find(Employee.class, empId);
		return ee;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		Employee ee = em.find(Employee.class,empId);
		ee.setEmpName(newName);
		ee.setEmpSal(newSal);
		entitytran.begin();
		em.merge(ee);
		entitytran.commit();
		
		return null;
	}

}
