package com.capgemini.ems.service;

import java.util.ArrayList;

import javax.persistence.EntityTransaction;

import com.capgemini.ems.bean.Employee;
import com.capgemini.ems.doa.EmployeeDao;
import com.capgemini.ems.doa.EmployeeDaoImp;

public class EmployeeServiceImp implements EmployeeService {
	EmployeeDao empDao = null;
	public EmployeeServiceImp() {
		empDao = new EmployeeDaoImp();
	}

	@Override
	public Employee addEmp(Employee emp) {
		// TODO Auto-generated method stub
		return empDao.addEmp(emp) ;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return empDao.fetchAllEmp();
	}

	@Override
	public Employee deleteEmp(int empId) {
		// TODO Auto-generated method stub
		return empDao.deleteEmp(empId);
	}

	@Override
	public Employee getEmpbyEid(int empId) {
		
		return empDao.getEmpbyEid(empId);
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		// TODO Auto-generated method stub
		
		return empDao.updateEmp(empId, newName, newSal) ;
	}

}
