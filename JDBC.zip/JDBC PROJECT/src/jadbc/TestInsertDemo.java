package jadbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.ems.util.DBUTIL;

public class TestInsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter empid ");
		int eid =  sc.nextInt();
		System.out.println("enter empname ");
		sc.nextLine();
		String ename =  sc.nextLine();
		System.out.println("enter salary ");
		float  esal =  sc.nextFloat();
		
		try {
			Connection con = DBUTIL.getCon();
			String insertQry = "Insert INTO abc"
					+"(emp_id,emp_name,emp_sal)"+"VALUES(?,?,?)";
			PreparedStatement pst = con.prepareStatement(insertQry);
			pst.setInt(1, eid);
			pst.setString(2, ename);
			pst.setFloat(3, esal);
			int data =  pst.executeUpdate();
			System.out.println("data insert"+data);
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		

	}

}
