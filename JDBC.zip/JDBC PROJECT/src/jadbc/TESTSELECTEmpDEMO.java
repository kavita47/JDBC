package jadbc;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class TESTSELECTEmpDEMO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement st=null;
		
		try {// this is the first step for the connection 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "Capgemini123");
			st=con.createStatement(); //using the connection we are getting the statement 
			ResultSet rs= st.executeQuery("SELECT * FROM abc");
			
			System.out.println("ID\t\t NAME\t\t SALARY\t\tJON");
			while(rs.next())
			{
				System.out.println(rs.getInt("emp_id")+"\t\t"+rs.getString("emp_name")
				+"\t\t"+rs.getInt("emp_sal")+"\t\t"+rs.getDate("emp_jon"));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); // 
		}
		

	}

}
