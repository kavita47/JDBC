package com.capgemini.takehome.service;



import java.math.BigDecimal;

import com.capgemini.takehome.bean.Client;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ClientIdCanNotBeNullExceptions;
import com.capgemini.takehome.exception.ClientIdDoesNotExistExceptions;
import com.capgemini.takehome.exception.ClientNameCanNotBeNullExceptions;
import com.capgemini.takehome.exception.DuplicateIdExceptions;

public abstract class ProductService implements IProductService {
	IProductDAO ip_pro_dao = (IProductDAO) new ProductDAO();
	Product product;

	public Client CreateClientAccount(String Client_name, String Client_Bill) throws ClientNameCanNotBeNullExceptions
		 {
		if(Client_name == null)  //if the client name is null it will throw the exception 
		{
			throw new ClientNameCanNotBeNullExceptions();
		}
		Client client = null;
		((IProductDAO) ip_pro_dao).Save_Client11(client);
		
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Client ShowClientBill(String Client_id)
			throws ClientIdDoesNotExistExceptions, ClientIdCanNotBeNullExceptions {
		Client client =ip_pro_dao.FindOneCustomer(Client_id);
		 if(client == null)
			{
				throw new ClientIdDoesNotExistExceptions();
			}
		
		
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Client CreateClientAccount(String Client_name, String Client_id, String Client_Bill)
			throws DuplicateIdExceptions, ClientNameCanNotBeNullExceptions {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}
