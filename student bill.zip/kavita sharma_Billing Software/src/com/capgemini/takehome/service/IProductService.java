package com.capgemini.takehome.service;

import java.math.BigDecimal;

import com.capgemini.takehome.bean.Client;
import com.capgemini.takehome.exception.ClientIdCanNotBeNullExceptions;
import com.capgemini.takehome.exception.ClientIdDoesNotExistExceptions;
import com.capgemini.takehome.exception.ClientNameCanNotBeNullExceptions;
import com.capgemini.takehome.exception.DuplicateIdExceptions;

  //Here we have created interface of the product service 
public interface IProductService {
	public Client CreateClientAccount(String Client_name, String Customer_MobileNo, String string) throws DuplicateIdExceptions,ClientNameCanNotBeNullExceptions;
	public Client ShowClientBill(String Client_id, String string) throws ClientIdDoesNotExistExceptions, ClientIdCanNotBeNullExceptions;
	Client CreateClientAccount(String Client_name, BigDecimal bigDecimal)
			throws DuplicateIdExceptions, ClientNameCanNotBeNullExceptions;
	Client ShowClientBill(String Client_id) throws ClientIdDoesNotExistExceptions, ClientIdCanNotBeNullExceptions;
	
	

}
