package com.capgemini.takehome.exception;

public class ClientIdCanNotBeNullExceptions extends Exception {

}
