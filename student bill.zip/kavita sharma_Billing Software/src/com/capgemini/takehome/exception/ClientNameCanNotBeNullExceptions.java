package com.capgemini.takehome.exception;

public class ClientNameCanNotBeNullExceptions extends Exception {

}
