package com.capgemini.takehome.exception;

public class DuplicateIdExceptions extends Exception {

}
