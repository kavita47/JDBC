package com.capgemini.takehome.exception;

public class DuplicateIdException {

}
