package com.capgemini.takehome.exception;

public class ClientIdDoesNotExistExceptions extends Exception {

}
