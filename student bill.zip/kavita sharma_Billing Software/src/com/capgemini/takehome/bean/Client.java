package com.capgemini.takehome.bean;

public class Client {
	private String client_name;
	private String client_id;
	private Product product;
	
	
	// Getter and Setter
	public String getClient_name() {
		return client_name;
	}
	/**
	 * @param client_name
	 * @param client_id
	 */
	// parameterized cunstroctor 
	public Client(String client_name, String client_id) {
		super();
		this.client_name = client_name;
		this.client_id = client_id;
	}
	@Override
	public String toString() {
		return "Client [client_name=" + client_name + ", client_id=" + client_id + "]";
	}
	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}
	public String getClient_id() {
		return client_id;
	}
	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	

}
