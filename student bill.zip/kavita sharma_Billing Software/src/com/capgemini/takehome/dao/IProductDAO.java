package com.capgemini.takehome.dao;


import com.capgemini.takehome.bean.Client;
import com.capgemini.takehome.bean.Product;

public interface IProductDAO {
	
public Boolean Save_Client11(Client client);
	
	public Client FindOneCustomer(String Client_id);

	

	public void CreateClientAccount1(String string, String string2, String string3);

	public void CreateClientAccount(String string, String string2, String string3);

	Boolean Save_Client(Client client);

	
}

	
	

	

	





