package com.capgemini.takehome.dao;

import java.util.Iterator;
import java.util.LinkedList;


import com.capgemini.takehome.bean.Client;
//Here we have implement the interface named IProductDAO
public class ProductDAO implements IProductDAO {
	
	LinkedList<Client> l2 = new LinkedList<>();
	
	
	
	public static void getProductDetails(int product_id) {
		
	}

	@Override
	public Boolean Save_Client(Client client) {
		// TODO Auto-generated method stub
		return l2.add(client);
	}

	@Override
	public Client FindOneCustomer(String Client_id) {
		Iterator<Client> itr = l2.iterator();
		while(itr.hasNext())
		{
			Client client = itr.next();
			if(client.getClient_id().equals(Client_id));
			{
				return client;
			}
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean Save_Client11(Client client) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void CreateClientAccount1(String string, String string2, String string3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void CreateClientAccount(String string, String string2, String string3) {
		// TODO Auto-generated method stub
		
	}
	

}
