package com.capgemini.takehome.test;

import java.math.BigDecimal;
import java.security.DigestException;

import org.junit.Before;
import org.junit.Test;


import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ClientIdCanNotBeNullExceptions;
import com.capgemini.takehome.exception.ClientNameCanNotBeNullExceptions;
import com.capgemini.takehome.exception.DuplicateIdExceptions;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Test1 {
	//here we have created the dao object 
	IProductDAO ip_pro_dao = (IProductDAO) new ProductDAO();
   
    
	@Before
	public void setUp() throws Exception {
	}
	

}

