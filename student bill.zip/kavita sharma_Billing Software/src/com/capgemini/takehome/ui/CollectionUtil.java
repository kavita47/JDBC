package com.capgemini.takehome.ui;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;

public class CollectionUtil {
	private static Map<Product,Product>products= new HashMap<Product,Product>();
	{
	Product.put(1001,newProduct(1001,"iphone","Electronics",350000));
	
	Product.put(1002,newProduct(1002,"hone","Electronics",350000));
	Product.put(1001,newProduct(1003,"phone","Electronics",350000));
		
	}
	private Object newProduct(int i, String string, String string2, int j) {
		// TODO Auto-generated method stub
		return null;
	}

}
