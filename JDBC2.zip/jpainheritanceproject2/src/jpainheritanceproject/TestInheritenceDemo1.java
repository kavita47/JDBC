package jpainheritanceproject;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class TestInheritenceDemo1 {

	public static void main(String[] args) {
		
		Emp rahul = new Emp();
		rahul.setEmpName("Rahul");
		rahul.setEmpSal(6000);
        		
		Manager vaishali = new Manager();
		vaishali.setDeptName("java");
		vaishali.setEmpName("vaishalis");
		vaishali.setEmpSal(6000);
		EntityManager em = JPAutil.getEntityManager();
		EntityTransaction tran = em.getTransaction();
		tran.begin();
		em.persist(vaishali);
		em.persist(rahul);
		tran.commit();
		System.out.println("data is inserted");
		
		
	}

}
